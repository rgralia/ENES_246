# LotsOfGates
Vivado turns all circuits into the primitives of a CLB Slice: LUTs, muxes, carry-logic, xor gates, d flip flops. Understanding these is the goal of this course. We have covered XOR gates.  The goal of this lab is to understand LUTs. 

The goal here is to predict [LookUpTables](https://en.wikipedia.org/wiki/Lookup_table) (LUTS) values.
Then find their contents in Vivado and compare.
Then look at how Vivado deals with identical circuits. 

## Project_1

Below is a diagram of a circuit with two outputs. The outputs are identical. The bottom part with two input gates reduces to the top circuit of one three input Nand gate. The circuit was built in  [logisim](https://sourceforge.net/projects/circuit/) which is a java runtime program free to download. The logisim circuit called [two identical circuits](https://github.com/ENES-246DigitalElectronics/ENES246/blob/master/-4LotsOfGates/TwoIdenticalCircuits.circ), can also be downloaded.  The top circuit uses one gate. The bottom circuit uses 5 gates.  The question is what does Vivado do with these circuits?

![1548098400293](1548098400293.png)

#### Port Diagram

![lab_4_1_port](C:\Users\SET253-03U.HCCMAIN\Desktop\lab_4_working\lab_4_1_port.PNG)

#### Verilog Code



`timescale 1ns / 1ps  

module vcb(  
   input  [2:0] SW,  
   output [1:0] LED  
   );  
   wire w1,w2,w3,w4;  
   and a1(w1,SW[0],SW[1]);   
   nor  o1(w2,~SW[1],~SW[2]);   
   nand a2(w3,SW[1],SW[2]);   
   or   o2(w4,w1,w2);  
   and  a3(LED[0],w3,w4);   
   assign LED[1] = SW[0] && SW[1] && !SW[2];   
endmodule





#### RTL Schematic Screen shot



![lab_4_1_RTL](lab_4_1_RTL.PNG)





#### Synthesis Schematic Screen shot



![lab_4__1_synthesis](lab_4__1_synthesis.PNG)







#### Implementation Device screen shot zoomed in on something interesting



![lab_4_1_ZOOM](lab_4_1_ZOOM.PNG)









#### Testing

SUCCESS; LEDs 0 &1 only light up when SW 0 & SW 1 are ON, all other combinations of SW 0,  SW 1 and SW 2 result in LEDs 0 & 1being OFF.











One might expect that Vivado would reduce these to a single circuit and reuse the circuit. There have been software packages that do this.  The logisim software can do this. Download logisim and the circuit above, and with this circuit open in logisim, go to project, analyze the circuit, minimize, set as expression for output x, set as expression for output y, ok, yes sure. *What happens?*

logisim reduced the multiple gates feeding the 'y' into one AND gate with a single NOT gate for the SW3, mirroring the gate feeding 'x' 







*Add screen shot of logisim of the resulting circuit.*  



![lab_4_1_logisim_reduced_circuit](lab_4_1_logisim_reduced_circuit.PNG)





Now explore what Vivado does in your screen shots above. Clearly Vivado could see two identical circuits. *What does Vivado do instead?*



vivado does what it was ordered to do, build 'y' with 5 gates and build 'x' with one gate.





To see Vivado LUT's truth tables, click on schematic, right click on the LUT and choose cell properties, move the tab from General to truth table. *Add screen shots of the Vivado LUT truth tables.* 



![lab_4_1_LUTs_truth_table](lab_4_1_LUTs_truth_table.PNG)





![lab_4_1_LUTs_truth_table_2](lab_4_1_LUTs_truth_table_2.PNG)







Obviously Vivado understands the verilog code. *How are the truth tables the same?* 

they are the same for  binary values; 0, 1, 2, 4, 6, 7

*How are the truth tables different? What did Vivado do to make the circuits different?* 

they are different for the binary values; 3, 5

## Project_2

Repeat project_1 with your own design. Develop two identical circuits. Build the first circuit with 3 inputs, 2 outputs and at least 5 gates. The second circuit can be a simple version of the first.  Then repeat the instructions of project 1.  Document your circuit with the port diagram and screen shots. 





![lab_4_2_logisim_orginal_B](lab_4_2_logisim_orginal_B.PNG)







#### Port Diagram



![lab_4_2_port](lab_4_2_port.PNG)





#### Verilog Code



![lab_4_2_verilog_code](lab_4_2_verilog_code.PNG)





#### RTL Schematic Screen shot



![lab_4_2_RTL](lab_4_2_RTL.PNG)



#### Synthesis Schematic Screen shot





![lab_4_2_synthesis](lab_4_2_synthesis.PNG)





#### Implementation Device screen shot zoomed in on something interesting



![lab_4_2_ZOOM](lab_4_2_ZOOM.PNG)







#### Testing

SUCCESS; follows logisim inputs/outputs;

SW0	SW1	SW2	LED0	LED1

0		0		0		1		0

1		0		0		1		0

0		1		0		1		0

1		1		0		1		0

0		0		1		1		0

1		0		1		0		1

0		1		1		1		1

1		1		1		0		1



LED0 lights up when no switches are engaged (LED1 OFF)

LED0 lights up when only SW0 is engaged (LED1 OFF)

LED0 lights up when only  SW1 is engaged (LED1 OFF)

LED0 lights up when only SW2 is engaged (LED1 OFF)

LED0 lights up when SW0 and SW1 are engaged (LED1 OFF)

LED0  light up when SW1 and SW2 are engaged (LED1 ON)

LED1 lights up when  SW0 & SW2 engaged (LED0 OFF)

LED1 lights up when SW1 & SW2 engaged (LED0 ON)

LED1 lights up when SW0, SW1 & SW2 engaged (LED0 OFF)



LOGISIM REDUCTION;





![Lab_4_2_logisim_reduction](Lab_4_2_logisim_reduction.PNG)



*Is anything different?* 

yes, kept same number of gates, but changed some gates....LED0 is now being controlled by two NOT gates (on SW2 and SW0) feeding one OR gate...LED1 is now being controlled by one OR gate, being fed by two AND gates, AND gate 1 is fed by SW1 & SW2, AND gate 2 is fed by SW0 and SW2.



LUTS;



![lab_4_2_LUTs(1)_truth](lab_4_2_LUTs(1)_truth.PNG)





![lab_4_2_LUTs(2)_truth_1](lab_4_2_LUTs(2)_truth_1.PNG)









# Ethics of choosing which Algorithms to Teach

You are student at a university. *Why would professors demand in the first course on digital circuit design that you learn  [Karnaugh Maps,](https://en.wikipedia.org/wiki/Karnaugh_map)  [Quine McCluskey Algorithm](https://en.wikipedia.org/wiki/Quine%E2%80%93McCluskey_algorithm), and  [Petrick Cover](https://en.wikipedia.org/wiki/Petrick%27s_method), which seems unrelated to the labs, doesn't predict Vivado behavior and is at best buried in the Vivado software?*



The old methods allow for thinking like a digital circuit and can help minimize a circuit design to make it less complicated with fewer gates.

 



Suppose you are engineer designing the Vivado software. You get the question from a customer, a fellow engineer using your companies product and paying your salary: "Why doesn't Vivado see one circuit?" Read this [forum post](https://forums.xilinx.com/t5/Synthesis/Question-about-LUT-usage-in-a-very-very-simple-combinatorial/td-p/221143).  *What is your answer to this question?*



vivado does what it is ordered to do...it does not make it's own rules, it follows your rules.





Engineers develop conspiracy theories when trying to predict the future. *Given the above chaos discovered in Vivado while doing the labs above, what do you expect to happen as you try to cram larger and larger circuits into an FPGA?* 

vivado will do as told, creating the large circuit you designed, as the circuits become too large, the FPGA may not be able to handle all that is being asked of it, it may 'fail to generate bitstream'.