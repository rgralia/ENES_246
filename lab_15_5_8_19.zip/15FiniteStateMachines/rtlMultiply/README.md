

Verilog Source

![1544638599762](1544638599762.png)

RTL Schematic

![1544638503457](1544638503457.png)

Synthesis Schematic

![1544638844675](1544638844675.png)

Utilization Summary

![1544639313670](1544639313670.png)

Implementation

![1544644534161](1544644534161.png)

Manual Testing

​	Can see a pattern of when ask to multiply by 2,4,8,16 ... just shifts the other number left	 

