# AndNand
The goals of this lab are to begin looking at the ways **Vivado** modifies our code.   

**Vivado** tires to get rid of constants.   

**Vivado** looks at different verilog abstractions of the same circuit and does what?   

**Vivado** simplifies circuits we tell it to build, freeing us from trying to build efficient circuits.

## project_1 constants

Project_1 is playing with voltage controlled buffers just like the previous lab, except it is using constants.

#### Port Diagram

![lab_3_1_port](C:\Users\SET253-03U.HCCMAIN\Desktop\lab_3_turn_in\lab_3_1_port.PNG)



![lab_3_1_port](lab_3_1_port.PNG)



#### Verilog Code

![1547913933708](1547913933708.png)

#### RTL Schematic Screen shot

![lab_3_1_rtl_schematic](C:\Users\SET253-03U.HCCMAIN\Desktop\lab_3_turn_in\lab_3_1_rtl_schematic.PNG)

![lab_3_1_rtl_schematic](lab_3_1_rtl_schematic.PNG)





#### Synthesis Schematic Screen shot



![lab_3_1_synthesis_schematic](C:\Users\SET253-03U.HCCMAIN\Desktop\lab_3_turn_in\lab_3_1_synthesis_schematic.PNG)

![lab_3_1_synthesis_schematic](lab_3_1_synthesis_schematic.PNG)

#### Implementation Device screen shot zoomed in on something interesting



![lab_3_1_zoom](C:\Users\SET253-03U.HCCMAIN\Desktop\lab_3_turn_in\lab_3_1_zoom.PNG)



![lab_3_1_zoom](lab_3_1_zoom.PNG)

#### Testing

sw0		sw1		LED0

0		 0		    0

0	  	  1	            1

1		  0		    1

1                1                1

acts like OR gate



*A logical 1 is visible in the verilog code (vcb.v) and yet the RTL analysis schematic gets rid of the logical constant and is identical to the previous lab. Why? Draw a diagram similar to the RTL analysis with containing the design intent of the verilog code.*

because the 1 is superfluous....it has no bearing on the operation of the circuit. 

*What happens if the order of 1 and sw0  are switched (and the order of 1 and sw1) in the verilog code?*

no obvious changes in RTL schematic.....

synthesis....the schematic no longer has luts 

implementation fails....

 ![lab_3_1_order_change_fail_error](C:\Users\SET253-03U.HCCMAIN\Desktop\lab_3_turn_in\lab_3_1_order_change_fail_error.PNG)

![lab_3_1_order_change_fail_error](lab_3_1_order_change_fail_error.PNG)

Comment out the lines:

​	set_property CFGBVS VCCO [current_design]
​	set_property CONFIG_VOLTAGE 3.3 [current_design]

in the xdc file. 

*What error messages are generated?*   



*Which (RTL, Synthesis, Implement or Generate Bitstream) causes failure?* 

passed RTL

passed synthesis

passed implementation

passed bitstream

passed programming....checked fpga, operates same as part 1 of this lab (sw0 & sw1 act as inputs to OR gate feeding the LED0)

*Which starts complaining first about these two lines?*

none, it passed all the xilinx steps.

*What technology is in the Xilinx FPGA we are using TTL, CMOS, etc. ? Provide a link to the web site where you looked up the answer.*

https://reference.digilentinc.com/reference/programmable-logic/nexys-4-ddr/reference-manual

must investigate further, cannot find at this time

*What is w in the verilog code? Is it necessary?* 

## project_2 andGates

In this project an "And" gate is created four different ways. Test it. Show your instructor all four ways working. 

#### Port Diagram



![lab_3_2_port](C:\Users\SET253-03U.HCCMAIN\Desktop\lab_3_turn_in\lab_3_2_port.PNG)

![lab_3_2_port](lab_3_2_port.PNG)



#### Verilog Code

`timescale 1ns / 1ps

module vcb(
   input  sw0,
   input  sw1,
   output [3:0] LED
   );
   wire nand1;
   and a1(LED[0],sw0,sw1);
   bufif1 b1(LED[1], sw0, sw1);
   nand n1(nand1,sw0,sw1);
   nand n2(LED[2],nand1,nand1);
   assign LED[3] = sw0 && sw1;

endmodule



#### RTL Schematic Screen shot



![lab_3_2_RTL_schematic](C:\Users\SET253-03U.HCCMAIN\Desktop\lab_3_turn_in\lab_3_2_RTL_schematic.PNG)

![lab_3_2_RTL_schematic](lab_3_2_RTL_schematic.PNG)



#### Synthesis Schematic Screen shot



![lab_3_2_synthesis_schematic](C:\Users\SET253-03U.HCCMAIN\Desktop\lab_3_turn_in\lab_3_2_synthesis_schematic.PNG)



![lab_3_2_synthesis_schematic](lab_3_2_synthesis_schematic.PNG)

#### Implementation Device screen shot zoomed in on something interesting



![lab_3_2_zoom](C:\Users\SET253-03U.HCCMAIN\Desktop\lab_3_turn_in\lab_3_2_zoom.PNG)



![lab_3_2_zoom](lab_3_2_zoom.PNG)

#### Testing

sw 0       sw 1      LED 1    LED  2     LED  3   LED 4

0	       0                0             0             0		0

0		1		 0 		0		0		0

1		0		 0		0		0		0

1		 1		1		1		1		1



both sw0 and sw1 must be ON in order for LEDs 0-3 to energize.

acts like AND gate





*Which of the four ways is the most attractive way to code?*

the assign command and &&;

assign LED[3] = sw0 && sw1;

seems the most succeint

*At what level of verilog code abstraction is the **assign** command?*

gate level

*Does order of the verilog commands (sequence of commands) change anything?*

no, changed order of "and a1(LED[0], sw0,sw1);" to last in line and unit operated same as before.

*What are a1,b1,n1,n2 associated with the gate names called in Verilog?*

they are internal wires that have been named by the programmer. they are being programmed to act like AND gates.



*In the language C, the names between () look like variables passing data to some kind of function, object or subroutine. What do the represent in verilog?* 



in verilog the () represent 



*At what step (RTL, Synthesis, Implementation, BitFile) did Vivado figure out that most of the LED's were doing the same thing?* 



*Implement each and gate one at a time. List any differences between them at the RTL or Synthesis states here. Take screen shots if you want or describe them verbally.* 



## project_3 XOR and Nand Gates

You create this from scratch.

Use the "[assign](https://www.utdallas.edu/~akshay.sridharan/index_files/Page5212.htm)" command, 3 switches, and 2 LEDs to create a three input Nand gate and a three input XOR gate. Put them all in one project. 

#### Port Diagram

![lab_3_3_port](lab_3_3_port.PNG)





#### Verilog Code

OLD/ERROR DOES NOT RUN PROPERLY ON BRD;

module Lab_3_3(
    input a,
    input b,
    input c,
    output x,
    output y
    );
    wire nand1;
    wire nand2;
    wire x1;
    wire x2;
    assign nand1= !(a&&b);
    assign nand2 = nand1 && !c;
    assign x1 = (a^b);
    assign x2 = (x1^c);
    assign x = (nand1 && nand2);
    assign  y = (x1^x2);
    
    
endmodule

REDONE CODE:

module lab_3_3_b(
    input [2:0] SW,
    output [1:0] LED
    );
    wire nand1;
 //   wire nand2;
    wire xor1;
    tri  y;
    tri  z;
    nand n1(nand1, SW[0],SW[1]);
    nand n2(y, nand1, SW[2]);
    xor x1(xor1, SW[0], SW[1]);
    xor x2(z, xor1, SW[2]);
    
    assign LED[0] = y;
    assign LED[1] = z;

​    
endmodule



NEWEST;CORRECT:

module lab_3_3_b(
    input [2:0] SW,
    output [1:0] LED
    );
    wire nand1;
 //   wire nand2;
    wire xor1;
    wire x;
    tri  y;
    tri  z;
    and n1(x, SW[0],SW[1]);
    nand n2(y, x, SW[2]);
    xor x1(xor1, SW[0], SW[1]);
    xor x2(z, xor1, SW[2]);
    
    assign LED[0] = y;
    assign LED[1] = z;

​    
endmodule





#### RTL Schematic Screen shot

OLD/ERROR;

![lab_3_3_RTL_schematic](lab_3_3_RTL_schematic.PNG)



NEW;



![lab_3_3_RTL_schematic_B](lab_3_3_RTL_schematic_B.PNG)



NEWEST;CORRECT;

![lab_3_3_RTL_schematic_c](lab_3_3_RTL_schematic_c.PNG)







#### Synthesis Schematic Screen shot

OLD/ERROR:

![lab_3_3_synthesis_schematic](lab_3_3_synthesis_schematic.PNG)



NEW:

![lab_3_3_synthesis_schematic_B](lab_3_3_synthesis_schematic_B.PNG)





NEWEST;CORRECT;



![Lab_3_3_synthesis_schematic_c](Lab_3_3_synthesis_schematic_c.PNG)





#### Implementation Device screen shot zoomed in on something interesting

![lab_3_3_ZOOM](lab_3_3_ZOOM.PNG)



NEW;



NEWEST;CORRECT;









#### Testing

OLD/ERROR;

a        b             c              x              y

0        0             0              1             0

1        0             0               1            0

0         1            0                1           0

1         0           0                 1           0

1          1          0                 0          0

1          1          1                0           0

0          0           1               1          0

1          0          1                1          0



ERROR did  not program right.....redoing code.......

NEW;

a	b	c	x	y

0	0	0	1	0

0	0	1	0	1

0	1	0	1	1

0	1	1	0	0

1	0	0	1	1

1	0	1	0	0

1	1	0	1	0

1	1	1	1	1



NEWEST;

a	b	c	x	y    a=sw0, b=sw1, c=sw2, x=led0, y=led1;

0	0	0	1	0

0	0	1	1	1

0	1	0	1	1

0	1	1	0	0

1	0	0	1	1

1	0	1	1	0

1	1	0	1	0

1	1	1	0	1







*XOR gates have evolved with [two different implementations](https://en.wikipedia.org/wiki/XOR_gate#More_than_two_inputs) with three or more inputs.  Which does the verilog assign command implement?*

verilog implements an ODD detector XOR gate (when three or more inputs)

## Ethics

The ethics questions below are more important than your answers. The goal in answering them is to remember the question. So the best answers are a non-trivial, thoughtful, relevant hypothesis. 

#### Ethics of EDIF

EDIF (Electric Design Interchange Format)  captures a battle between engineers trying to use tools like Vivado and engineers designing Vivado. They both have to make money. *Summarize this wikipedia article  on the death of [EDIF](https://en.wikipedia.org/wiki/EDIF) standards in less than 200 words:*

This course is asking you to document circuits first with the port diagram and then screen shots of Vivado and finally a discussion of testing. You are in the role of an engineering using Vivado on a project. *Which verilog version of the project_1 circuit (simple or complex) should be entered into Vivado?  When is a more complex circuit a good thing and a simplified, reduced circuit a bad thing?*



