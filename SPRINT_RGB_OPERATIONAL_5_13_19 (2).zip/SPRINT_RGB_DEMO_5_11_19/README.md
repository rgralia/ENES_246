5.10.19     RGB PWM from DEMO

notes;

 project_1 has building block, was worked on by Steve & reed, goal was to make LED16 BLUE controllable by manual inputs

project_2 is first bitstream attempt...semi-success>>LED16 BLUE controllable by manual input but only has one output of LED16 BLUE being very weak (brightness wise)....fault was having push button as manual input which can./could only have one level of strength (one bits worth)



project_3 is change of manual input as single bit input (push button) to seven bit input by means of SW[7:0]....generated bitstream....success>>>LED16 BLUE strength is controllable by making SW[7:0] HIGH>>>>so if

SW[0] goes HIGH then LED16 BLUE has faint glow

SW[1] HIGH then LED16 BLUE has slightly brighter glow

SW[2] HIGH then LED16 BLUE has slightly brighter glow still

.....

....

....

SW[7] HIGH then LED16 BLUE is strong

brightest output when SW[7:0] HIGH (linear), is hard for my eye to detect but this is brightest option (256 bit input). Combining various SW combinations gets varying strength output on LED16 BLUE







NEXT STEP;

get other colors/ 2nd RGB LED operational

get 8 bits controlling PWM (brightness)

get 6 bits dedicated SELECT (to control which RGB LED is being controlled)

get 1 bit controlling ENTER (to 'upload' PWM and SELECT values)

possibly get 1 bit controlling BANK (to increase holding values)    

   -- reed 5.10.19 @ 2:30pm





5.13.19

got two LEDs w/ all three colors operational w/ pwm control....added to github called "project_3_1_OPERATIONAL"

got two LEDs w/ all three colors op w/ pwm control ONLY when ENABLE switch is HIGH...added to github called "project_3_2_COMPLETE"

next get Jordan's latching operational on our verilog (?)

