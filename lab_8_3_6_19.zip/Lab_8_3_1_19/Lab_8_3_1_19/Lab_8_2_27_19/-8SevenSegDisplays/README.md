You have tested a Voltage Controlled Buffer VCB in Lab 2.

You have built muxes in Lab 5

Now is the time to start putting all these pieces together in a larger project. 

# 1_SevenSegDisplays

The goal of this project is to manually explore how a 7 seg Display works. You just need to shoot screen shots and test.

#### Port Diagram









#### Verilog Code



![Lab_8_1](Lab_8_1.PNG)









#### RTL Schematic Screen shot



![Lab_8_1_RTL](Lab_8_1_RTL.PNG)













#### Synthesis Schematic Screen shot



![Lab_8_1_synthesis](Lab_8_1_synthesis.PNG)









#### Implementation Device screen shot zoomed in on something interesting



![Lab_8_1_ZOOM](Lab_8_1_ZOOM.PNG)















#### Testing

1 individual seven segment display cell has eight individual cathodes inputs and 1 common anode feed; if the 1 common anode feed is set to HIGH (1) then that entire seven segment cell  is extinguished, regardless of cathode input values.....to make just the last seven segment cell active (left to right) ; turn SW[15:9] to HIGH leaving SW[8] LOW (other wise they all are duplicating inputs on SW[6:0])...to make the last active cell operate; make SW[7] HIGH to extinguish decimal point....to make segments G-A on seven-segment display go out, make SW[6:0] HIGH   (segment G corresponds to SW[6}, segment A corresponds to SW[0]).



## 2 _HexTo7SegDisplay

Here the goal is to explore how to display Hex on a 7 Seg Display. The problem is how to display 10,11,12,13,14,15 which are possible with 4 switches. 

![1549030304451](1549030304451.png)There is some logic behind this code. Look at the equation for seg(6) or g. Only three numbers turn off  segment g: **0, 1 or 7**,  **0001 or 0111**, (**~x[3] & ~x[2] & ~x[1]** ) |(**x[2] & x[1] & x[0]** ). 

Is this obvious to a electrical or computer engineer working in the field?  **Yes.** 

10 in hex is a. 11 in hex is b. 12 in hex is c. 13 in hex is d. 14 in hex is E and 15 in hex is F.
*Modify this project so that the above characters are Propose assign statements for these 6 displays for the letters of hex in a manner similar to the way 0,1,23,4,5,6,7,8 and 9 are displayed.* 

![1549986862526](1549986862526.png)

#### Port Diagram

   for get this ... there should have been a port diagram for this project 

#### Verilog Code

   paste your modified code here

#### RTL Schematic Screen shot

  make this of your modified code

#### Synthesis Schematic Screen shot

  make this of your modified code

#### Implementation Device screen shot zoomed in on something interesting

  make this of your modified code

#### Testing

testing the modified and unmodified should be the same

## 3_d7SegDisplay

#### Port Diagram 

xxxxx don't try to draw xxxxxx

#### Verilog Code

shoot screen shot



![lab_8_3_verilog](lab_8_3_verilog.PNG)







#### RTL Schematic Screen shot



![Lab_8_3_RTL](Lab_8_3_RTL.PNG)









#### Synthesis Schematic Screen shot



![lab_8_3_synthesis](lab_8_3_synthesis.PNG)









#### Implementation Device screen shot zoomed in on something interesting



![lab_8_3_ZOOM](lab_8_3_ZOOM.PNG)













#### Testing

oh Vivado; the LUT inputs & truth table are not logical (mine) matches...LUT4 feeding A segment on 7 segment display;

input     port    (LUT4) 

3		I0

2   		I1

0		I2

1		I3    



I0 = 8

I1 = 4

I3 = 2

I2 = 1

t. table 

inputs;	        I3	I2	I1	I0              output

 binary    0 =   0	0	0	0    		0 (seg A stays ON)

binary	8 =	0	0	0	1		0 (seg A stays ON)

binary     4 =  0	0	1	0		1 (seg A goes OFF)

binary     1 =   1     0      0      0             1 (seg A goes OFF)



FU Vivado...why aren't the inputs logically matched to the LUT ports (input 0 to I0, input 1 to I1, input 2 to I2 and input 3 to I3) instead of as it is, with a seemingly random connection to ports on the LUT. 

All LUTs in this example have the same illogical connection between input wires and LUT ports. 



ALL together (LUTs and inputs)

input        I3	I2	I1	I0       output

0          =    0	0	0	0         seg. g gets a 1 and goes OFF (creates '0' on 7-seg)

1	    =    1	0	0	0        seg.s a, d, e,f,g  get a 1 and go OFF (creates '1' on 7-seg)

2         =    0	1	0	0         seg.s c, f get a 1 and go OFF (creates '2' on 7-seg)

...

10      =    1	0	0	1       seg. d gets a 1 and goes OFF (creates 'A' on 7 seg)

11      =    1	1	0	1       seg.s a, b get a 1 and goes OFF (creates 'b' on 7 seg)

15     =     1	1	1	1       seg.s b, c,d get a 1 and goes OFF (creates 'F' on 7 seg)











------

#### Prompts

*Can you explain how this spreadsheet was formed and it's relationship to the code above?*

i assume the 'spreadsheet' references the LUTs for each segment (a-g) in the '3d-7segDisplay' above; then the 'a' segment needs to be ON (receiving a ZERO signal) anytime that the 'a' segment is required; i.e. 0,2,3,5,6,7,8,9,A,C,E,F...when these need to be displayed a truth table can be formed/programmed into  the segment 'a' LUT that has minterms at 1,4,11,13

repeat this for segments b-g

*In this lab there is another folder named 7SEG. Find the code that does something similar and shoot a screen shot of it here.* 









*Discuss the pros and cons of all three and pick one of them.*

## 4_d4x7segDisplay

#### Port Diagram

xxxxx don't try to draw xxxxxx

#### Verilog Code

![Lab_8_4_verilog_a](Lab_8_4_verilog_a.PNG)









#### RTL Schematic Screen shot



![Lab_8_4_RTL](Lab_8_4_RTL.PNG)





#### Synthesis Schematic Screen shot







![Lab_8_4_synthesis](Lab_8_4_synthesis.PNG)









#### Implementation Device screen shot zoomed in on something interesting



![Lab_8_4_ZOOM](Lab_8_4_ZOOM.PNG)











#### Testing

 4 seven segments are under operational control....L to R seven segment....1st seven segment is engaged when SW 12 and SW 13 are low...2nd seven segment display is engaged when SW 12 is high and SW 13 is LOW.....3rd seven segment display is engaged when SW12 is LOW and SW13 is HIGH....4th seven segment display is engaged when SW12 and SW13 are both HIGH.....SW[3:0] feed 1st seven segment display and binary input on those gets the corresponding hex output on 1st seven segment display w/ SW15 controlling the decimal point......SW[7:4] feed 2nd seven segment display and binary input on those gets the corresponding hex output on seven segment display w/ SW 14 controlling decimal point.....SW[11:8] feed BOTH the 3rd and 4th seven segment display (simultaneously) and binary input on those gets the corresponding hex output on 3rd and 4th seven segment display w/ SW15 controlling the decimal point on the 3rd seven segment display and SW14 & SW15 controlling the decimal point on the 4th seven segment display.

Thus...input of 0010 on SW[3:0] and input of 1101 on SW[7:4] and input of 1100 on SW[11:8] would set values of; 2 on segment 1....d on segment 2.....c on segments 3 &4.....confirmed...when SW 12 & SW13 are low: 2 is displayed on 1st seven seg display...when SW12 is HIGH.. d is displayed on 2nd seven segment display....when SW13 is HIGH c is displayed on 3rd seven segment display...when SW12 & SW13 are BOTH HIGH c is displayed on the 4th seven segment display.















------

#### Prompts

This really shouldn't be called 4 segment displays. *How many displays does it really use?*

4, but two are identical to each other

[Resource Utilization](https://forums.xilinx.com/t5/Implementation/Vivado-utilization-report/td-p/317517) forum question and answer.  Read this and do a screen shot of resource utilization of the last project above, so when this project is finished they can be compared.

## 5_32bitsHexTo7seg

This is working! Goal is to figure out how to use it in future labs.

#### Port Diagram![Port7Seg](Port7Seg.svg)

#### Verilog Code

![1550262534509](1550262534509.png)

#### RTL Schematic Screen shot 

![1550261669602](1550261669602.png)

#### Synthesis Schematic Screen shot

![1550261786527](1550261786527.png)

#### Implementation Device screen shot zoomed in on something interesting

 Lots of stuff going on

![1550262021286](1550262021286.png)

Lot more flip flops being used to count, remember things.

![1550262335962](1550262335962.png)

------

#### Testing

Left most switch[15]  pauses the counting.
Switch[14] resets to 0, pausing on a random segment
Switches 0 through 2 control the decimal place. 



SW[15] HIGH pauses program

SW[14] resets program to Zero

SW[13] HIGH causes 7 segment to display BCD and causes LEDs to display counting pattern (starting L to R) that matches 7 segment display, if SW[12] LOW LEDs display [31:16] of BCD if SW[12] LOW LEDs display [15:0] of BCD.

SW[13] LOW causes 7 segment to display HEX and causes LEDs to display counting pattern (starting L to R by fours [15:0] that matches 7 segment display, value shifts to next four LEDs as numbers get bigger...When SW[12] LOW LEDs display;

SW[13] HIGH SW[12] LOW 7segment displays clock counter and LEDs display clock input [31:16]

SW[13] HIGH SW[12]HIGH 7segment displays clock counter and LEDs display clock input [15:0]



SW[12] HIGH slows counting (by factor of 5000) and cycles LEDs through [31:16] and [15:0] of whichever value definition that is being looked at. 





------

#### Prompts

*What does the utilization report look like?*

![1550263073845](1550263073845.png)

*Which* *counter would you delete if another program was controlling the number to be displayed? Cut and paste a picture of the code that would be deleted in order to do this.*

![1550263932331](../../ENES247/lab3-ReusableBCDhex7segDisplayCode/1550263932331.png)



*What 32 bit variable name that you would add as an input to this module, and connect it to a top level with something to display? (Hint right now it is seeded with a constant.)* c_input

*Are clk, reset, stop_start, count_clk, divider_counter needed if the counter clock is removed?* clk is still needed. Everything else will not be mentioned in the code if the counter clock is removed. 

*What will have to be changed if the 32 bit Hex to BCD code is added?* c_input will be feed into the hex to BCD circuit, the output of the circuit will require modification of the //hex selector circuit, replacing c_input. 

*What variable controls how fast the counting is done?* divide_counter.

*To slow down the counting, what would need to be done ... make the number larger or smaller?* Larger. 

*Modify the screen code shot above with red boxes around all the commands that are new to you.* 

## Next Steps

Add gray out or dim
Add blink at four different rates
StopWatch support
Alphabet support

: colon support for in the future .. or try to get to work now

### Ethics of Different Institutional Objectives

There are three groups of Engineers with different objectives:

1. Engineers work for vendors .. For example Engineers work to improve Xilinx hardware FPGAs and Xilinx Vivado software to use them.
2. Engineers work for commercial/defense companies. Some use Xilinx. Others use Xilinx's competition. 
3. Engineers work for educational institutions. They teach and create open source, public, free tools for their doctorate degrees. Their students build circuits with a variety of tools and don't try to be an expert at one of them. 

*Describe one area where these three different institutions conflict.* 

new products: the vendors will want to push new products while the working and teaching engineers may  not be open to new designs/products (due to entrenched ideas/ comfort levels / reliability issues)

*Describe where the FPGA companies like Xilinx and the open source world conflict.*

*In what way are engineers removed from their employer's competing goals and more free to work together in standards committees?*

*What does an engineer represent ... like a lawyer representing clients, doctors representing patients?*

the engineer represents the company they work for, everything they do will be attributed to the company.  

*What motivates all three groups of engineers to start cooperating and working together building a common standard such as the next version of Verilog?* 

one would think that the common goal of a streamlined verilog/common standard that everyone could agree on would be ideal, but history tells me that everyone has their own ideas of the perfect version of something and the larger the group of independent minds, the harder it is to get them to agree on something (i.e. US congress)

*Why has the [US supreme court](https://supreme.justia.com/cases/federal/us/435/679/) ruled that engineers from competing companies meeting and forming organizations is not price fixing, is **not** [anti-competitive collusion](https://caselaw.findlaw.com/us-supreme-court/435/679.html)?* 

lawyers use lots of words...."The Sherman  Act does not require competitive bidding; it prohibits unreasonable restraints on competition." The court found that organizations being formed was not price fixing as found in the precedent of Mitchel v Reynolds; a temporary and limited loss of competition is out weighed by "the long-run benefit of enhancing the marketability of the business itself- and thereby providing incentives to develop such an enterprise.."

